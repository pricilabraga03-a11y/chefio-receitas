/* Chefio Receitas – interações do site (sem bibliotecas externas). */
(function () {
  'use strict';

  var enc = encodeURIComponent;

  /* minúsculas e sem acentos, para a busca ignorar maiúsculas e acentuação */
  function norm(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  }

  /* pequenas variações para achar "limões" ao digitar "limão", "ovos" ao digitar "ovo", etc. */
  function variantes(t) {
    var v = [t];
    if (/oes$/.test(t)) v.push(t.replace(/oes$/, 'ao'));
    if (/aes$/.test(t)) v.push(t.replace(/aes$/, 'ao'));
    if (/s$/.test(t) && t.length > 3) v.push(t.slice(0, -1));
    return v;
  }

  function parametros() {
    var q = typeof window.__CHEFIO_QS__ === 'string' ? window.__CHEFIO_QS__ : location.search;
    return new URLSearchParams(q);
  }


  /* ------------------------------------------------------------------
     Armazenamento no navegador (favoritos, lista de compras e tema).
     Tudo fica só no aparelho da pessoa; nada é enviado para fora.
     Se o navegador bloquear o armazenamento, usa a memória da página.
     ------------------------------------------------------------------ */
  var K_FAV = 'chefio:favoritos', K_COMP = 'chefio:compras', K_TEMA = 'chefio:tema';
  var memoria = {};

  function ler(chave, padrao) {
    try {
      var v = window.localStorage.getItem(chave);
      if (v !== null) return JSON.parse(v);
    } catch (e) { /* ignora */ }
    return (chave in memoria) ? memoria[chave] : padrao;
  }
  function gravar(chave, valor) {
    memoria[chave] = valor;
    try { window.localStorage.setItem(chave, JSON.stringify(valor)); } catch (e) { /* ignora */ }
  }
  function lista(chave) { var v = ler(chave, []); return Array.isArray(v) ? v : []; }

  function aviso(bloco, msg) {
    var t = bloco && bloco.querySelector ? bloco.querySelector('.toast') : null;
    if (!t) return;
    t.textContent = msg;
    clearTimeout(t._t);
    t._t = setTimeout(function () { t.textContent = ''; }, 2800);
  }

  /* ---------- tema claro/escuro ---------- */
  function temaAtual() {
    var a = document.documentElement.getAttribute('data-theme');
    if (a === 'dark' || a === 'light') return a;
    return (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
  }
  (function () {
    var salvo = ler(K_TEMA, null);
    if (salvo === 'dark' || salvo === 'light') document.documentElement.setAttribute('data-theme', salvo);
  })();

  /* ---------- favoritos ---------- */
  var reaplicarCatalogo = null;

  function atualizarFavs(raiz) {
    var f = lista(K_FAV);
    [].forEach.call((raiz || document).querySelectorAll('[data-fav]'), function (b) {
      var on = f.indexOf(b.getAttribute('data-fav')) !== -1;
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
      var rotulo = b.querySelector('span');
      if (b.hasAttribute('data-fav-texto') && rotulo) rotulo.textContent = on ? 'Salva' : 'Salvar';
      var card = b.closest('.card');
      if (card) {
        var h = card.querySelector('h3');
        var nome = h ? h.textContent : 'receita';
        b.setAttribute('aria-label', on ? 'Remover ' + nome + ' dos favoritos' : 'Salvar ' + nome + ' nos favoritos');
      }
    });
  }

  function alternarFav(slug) {
    var f = lista(K_FAV), i = f.indexOf(slug);
    if (i === -1) f.push(slug); else f.splice(i, 1);
    gravar(K_FAV, f);
    return i === -1;
  }

  /* ---------- lista de compras ---------- */
  function compras() { return lista(K_COMP); }
  function salvarCompras(l) { gravar(K_COMP, l); contarCompras(); }

  function contarCompras() {
    var n = compras().filter(function (i) { return !i.ok; }).length;
    [].forEach.call(document.querySelectorAll('[data-compras-count]'), function (el) {
      el.textContent = String(n);
      el.hidden = n === 0;
    });
  }

  function adicionarReceitaALista(art) {
    var slug = art.getAttribute('data-slug'), titulo = art.getAttribute('data-titulo');
    var itens = [].map.call(art.querySelectorAll('.lista-ing li span'), function (s) { return s.textContent.trim(); });
    var atual = compras(), novos = 0;
    itens.forEach(function (txt, idx) {
      var id = slug + '#' + idx;
      if (atual.some(function (i) { return i.id === id; })) return;
      atual.push({ id: id, slug: slug, receita: titulo, texto: txt, ok: false });
      novos++;
    });
    salvarCompras(atual);
    return novos;
  }

  function textoDaLista() {
    var grupos = {}, ordem = [];
    compras().forEach(function (i) {
      if (i.ok) return;
      if (!grupos[i.slug]) { grupos[i.slug] = { nome: i.receita, itens: [] }; ordem.push(i.slug); }
      grupos[i.slug].itens.push(i.texto);
    });
    var linhas = ['Lista de compras – Chefio Receitas'];
    ordem.forEach(function (s) {
      linhas.push('', grupos[s].nome);
      grupos[s].itens.forEach(function (x) { linhas.push('- ' + x); });
    });
    return linhas.join('\n');
  }

  function el(tag, classe, texto) {
    var e = document.createElement(tag);
    if (classe) e.className = classe;
    if (texto !== undefined) e.textContent = texto;
    return e;
  }

  function iniciarCompras(raiz) {
    var alvo = raiz.querySelector('[data-compras-pagina]');
    if (!alvo) return;
    var confirmando = false, timer = null;

    function copiar2(txt, bloco) { copiar(txt, bloco, 'Lista copiada!'); }

    function resumo(elRes) {
      var l = compras(), ok = l.filter(function (i) { return i.ok; }).length;
      elRes.textContent = l.length + (l.length === 1 ? ' item' : ' itens') + ' na lista, ' + ok + (ok === 1 ? ' marcado' : ' marcados');
    }

    function desenhar() {
      var l = compras();
      alvo.textContent = '';
      if (!l.length) {
        var vazio = el('div', 'vazio');
        vazio.appendChild(el('p')).appendChild(el('strong', '', 'Sua lista está vazia.'));
        vazio.appendChild(el('p', '', 'Abra uma receita e toque em "Adicionar à lista" para juntar os ingredientes aqui.'));
        var a = el('a', 'btn btn--verde', 'Ver receitas');
        a.setAttribute('href', 'receitas.html');
        vazio.appendChild(a);
        alvo.appendChild(vazio);
        return;
      }
      var barra = el('div', 'compras__barra');
      var res = el('p', 'contagem', '');
      res.setAttribute('aria-live', 'polite');
      barra.appendChild(res);
      var acoes = el('div', 'compras__acoes');
      var bCopiar = el('button', 'btn-share', 'Copiar lista'); bCopiar.type = 'button';
      var bZap = el('a', 'btn-share', 'Enviar por WhatsApp');
      bZap.setAttribute('href', 'https://wa.me/?text=' + enc(textoDaLista()));
      bZap.setAttribute('target', '_blank'); bZap.setAttribute('rel', 'noopener noreferrer');
      var bMarc = el('button', 'btn-share btn-share--sec', 'Remover marcados'); bMarc.type = 'button';
      var bTudo = el('button', 'btn-share btn-share--sec', confirmando ? 'Confirmar: limpar tudo' : 'Limpar tudo'); bTudo.type = 'button';
      if (confirmando) bTudo.className += ' btn-share--perigo';
      var aviso1 = el('span', 'toast'); aviso1.setAttribute('role', 'status'); aviso1.setAttribute('aria-live', 'polite');
      [bCopiar, bZap, bMarc, bTudo, aviso1].forEach(function (x) { acoes.appendChild(x); });
      barra.appendChild(acoes);
      alvo.appendChild(barra);
      resumo(res);

      bCopiar.addEventListener('click', function () { copiar2(textoDaLista(), acoes); });
      bMarc.addEventListener('click', function () {
        salvarCompras(compras().filter(function (i) { return !i.ok; }));
        desenhar();
      });
      bTudo.addEventListener('click', function () {
        if (!confirmando) {
          confirmando = true;
          clearTimeout(timer);
          timer = setTimeout(function () { confirmando = false; desenhar(); }, 4000);
          desenhar();
          return;
        }
        confirmando = false; clearTimeout(timer);
        salvarCompras([]);
        desenhar();
      });

      var ordem = [], porReceita = {};
      l.forEach(function (i) {
        if (!porReceita[i.slug]) { porReceita[i.slug] = { nome: i.receita, itens: [] }; ordem.push(i.slug); }
        porReceita[i.slug].itens.push(i);
      });
      ordem.forEach(function (slug) {
        var g = porReceita[slug];
        var sec = el('section', 'compras__grupo');
        var cab = el('div', 'compras__cab');
        var h = el('h2'); var link = el('a', '', g.nome);
        link.setAttribute('href', 'receitas/' + slug + '.html');
        h.appendChild(link); cab.appendChild(h);
        var rem = el('button', 'link', 'Remover receita'); rem.type = 'button';
        rem.addEventListener('click', function () {
          salvarCompras(compras().filter(function (i) { return i.slug !== slug; }));
          desenhar();
        });
        cab.appendChild(rem);
        sec.appendChild(cab);
        var ul = el('ul', 'lista-ing');
        g.itens.forEach(function (i) {
          var li = el('li'); var lb = el('label');
          var cx = el('input'); cx.type = 'checkbox'; cx.checked = !!i.ok;
          var sp = el('span', '', i.texto);
          cx.addEventListener('change', function () {
            var atual = compras();
            atual.forEach(function (x) { if (x.id === i.id) x.ok = cx.checked; });
            salvarCompras(atual);
            resumo(res);
            bZap.setAttribute('href', 'https://wa.me/?text=' + enc(textoDaLista()));
          });
          lb.appendChild(cx); lb.appendChild(sp); li.appendChild(lb); ul.appendChild(li);
        });
        sec.appendChild(ul);
        alvo.appendChild(sec);
      });
    }
    desenhar();
  }

  /* ---------- modo cozinha ---------- */
  var cozinhaAberta = false;

  function abrirCozinha(art, abridor) {
    if (cozinhaAberta) return;
    var titulo = art.getAttribute('data-titulo');
    var passos = [].map.call(art.querySelectorAll('.passos p'), function (p) { return p.textContent; });
    if (!passos.length) return;
    cozinhaAberta = true;
    var i = 0, lock = null;

    var caixa = el('div', 'cozinha');
    caixa.setAttribute('role', 'dialog'); caixa.setAttribute('aria-modal', 'true');
    caixa.setAttribute('aria-labelledby', 'coz-titulo');

    var topo = el('div', 'cozinha__topo');
    var tit = el('strong', '', titulo); tit.id = 'coz-titulo';
    var btns = el('div', 'cozinha__btns');
    var bIng = el('button', 'btn btn--contorno btn--peq', 'Ingredientes'); bIng.type = 'button'; bIng.setAttribute('aria-expanded', 'false');
    var bFechar = el('button', 'btn btn--laranja btn--peq', 'Fechar'); bFechar.type = 'button';
    btns.appendChild(bIng); btns.appendChild(bFechar);
    topo.appendChild(tit); topo.appendChild(btns);

    var prog = el('div', 'cozinha__prog');
    var barra = el('div', 'cozinha__barra'); var enchimento = el('i'); barra.appendChild(enchimento);
    var rot = el('span', '', ''); rot.setAttribute('aria-live', 'polite');
    prog.appendChild(barra); prog.appendChild(rot);

    var corpo = el('div', 'cozinha__corpo');
    var txt = el('p', 'cozinha__passo', '');
    corpo.appendChild(txt);

    var painel = el('div', 'cozinha__ing'); painel.hidden = true;
    var ingOrig = art.querySelector('.ingredientes');
    if (ingOrig) {
      var clone = ingOrig.cloneNode(true);
      [].forEach.call(clone.querySelectorAll('.dica-check, h2'), function (n) { n.remove(); });
      painel.appendChild(el('h2', '', 'Ingredientes'));
      painel.appendChild(clone);
    }

    var nav = el('div', 'cozinha__nav');
    var bAnt = el('button', 'btn btn--contorno', 'Anterior'); bAnt.type = 'button';
    var bProx = el('button', 'btn btn--verde', 'Próximo'); bProx.type = 'button';
    nav.appendChild(bAnt); nav.appendChild(bProx);

    [topo, prog, corpo, painel, nav].forEach(function (x) { caixa.appendChild(x); });
    document.body.appendChild(caixa);
    document.body.classList.add('sem-rolagem');

    function mostrar() {
      txt.textContent = passos[i];
      rot.textContent = 'Passo ' + (i + 1) + ' de ' + passos.length;
      enchimento.style.width = ((i + 1) / passos.length * 100) + '%';
      bAnt.disabled = i === 0;
      bProx.textContent = i === passos.length - 1 ? 'Concluir' : 'Próximo';
    }

    function pedirTela() {
      try {
        if (navigator.wakeLock && navigator.wakeLock.request) {
          navigator.wakeLock.request('screen').then(function (l) { lock = l; }, function () {});
        }
      } catch (e) { /* opcional */ }
    }
    function visib() { if (document.visibilityState === 'visible' && cozinhaAberta) pedirTela(); }

    function fechar() {
      cozinhaAberta = false;
      document.removeEventListener('visibilitychange', visib);
      try { if (lock && lock.release) lock.release(); } catch (e) { /* ignora */ }
      caixa.remove();
      document.body.classList.remove('sem-rolagem');
      if (abridor && abridor.focus) abridor.focus();
    }

    bProx.addEventListener('click', function () { if (i < passos.length - 1) { i++; mostrar(); } else { fechar(); } });
    bAnt.addEventListener('click', function () { if (i > 0) { i--; mostrar(); } });
    bFechar.addEventListener('click', fechar);
    bIng.addEventListener('click', function () {
      var abrir = painel.hidden;
      painel.hidden = !abrir;
      corpo.hidden = abrir;
      bIng.setAttribute('aria-expanded', abrir ? 'true' : 'false');
      bIng.textContent = abrir ? 'Voltar ao passo' : 'Ingredientes';
    });
    caixa.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.preventDefault(); fechar(); return; }
      if (e.key === 'ArrowRight' && !e.target.matches('input')) { if (i < passos.length - 1) { i++; mostrar(); } return; }
      if (e.key === 'ArrowLeft' && !e.target.matches('input')) { if (i > 0) { i--; mostrar(); } return; }
      if (e.key === 'Tab') {
        var foco = [].filter.call(caixa.querySelectorAll('button, input, a[href]'), function (x) { return !x.disabled && x.offsetParent !== null; });
        if (!foco.length) return;
        var primeiro = foco[0], ultimo = foco[foco.length - 1];
        if (e.shiftKey && document.activeElement === primeiro) { e.preventDefault(); ultimo.focus(); }
        else if (!e.shiftKey && document.activeElement === ultimo) { e.preventDefault(); primeiro.focus(); }
      }
    });
    document.addEventListener('visibilitychange', visib);
    pedirTela();
    mostrar();
    bProx.focus();
  }

  /* ------------------------------------------------------------------
     Catálogo: busca + filtros
     ------------------------------------------------------------------ */
  function iniciarCatalogo(raiz) {
    var grade = raiz.querySelector('#grade');
    if (!grade) return;

    var cards = [].slice.call(grade.querySelectorAll('.card'));
    var campo = raiz.querySelector('#busca');
    var selDif = raiz.querySelector('#f-dif');
    var selTempo = raiz.querySelector('#f-tempo');
    var selRef = raiz.querySelector('#f-ref');
    var contagem = raiz.querySelector('#contagem');
    var vazio = raiz.querySelector('#vazio');
    var chips = [].slice.call(raiz.querySelectorAll('.chip[data-cat]'));
    var form = raiz.querySelector('[data-filtro-form]');
    var estado = { cat: '', favs: false };
    var chipFav = raiz.querySelector('[data-fav-filtro]');
    var vazioTxt = raiz.querySelector('#vazio-txt');
    var textoVazioPadrao = vazioTxt ? vazioTxt.textContent : '';
    var usaUrl = typeof window.__CHEFIO_QS__ !== 'string';

    var p = parametros();
    if (p.get('q')) campo.value = p.get('q');
    if (p.get('cat')) estado.cat = p.get('cat');

    function marcarChips() {
      chips.forEach(function (c) {
        c.setAttribute('aria-pressed', c.getAttribute('data-cat') === estado.cat ? 'true' : 'false');
      });
    }

    function aplicar() {
      var termos = norm(campo.value).split(/\s+/).filter(Boolean);
      var dif = selDif.value, tempo = selTempo.value, ref = selRef.value;
      var total = 0;
      var salvas = estado.favs ? lista(K_FAV) : [];

      cards.forEach(function (c) {
        var ok = true;
        var texto = c.getAttribute('data-busca');
        termos.forEach(function (t) {
          if (!variantes(t).some(function (v) { return texto.indexOf(v) !== -1; })) ok = false;
        });
        if (estado.cat && c.getAttribute('data-cat') !== estado.cat) ok = false;
        if (estado.favs && salvas.indexOf(c.getAttribute('data-slug')) === -1) ok = false;
        if (dif && c.getAttribute('data-dif') !== dif) ok = false;
        var minutos = Number(c.getAttribute('data-tempo'));
        if (tempo === '30' && minutos > 30) ok = false;
        if (tempo === '60' && minutos > 60) ok = false;
        if (tempo === 'mais' && minutos <= 60) ok = false;
        if (ref && (' ' + c.getAttribute('data-ref') + ' ').indexOf(' ' + ref + ' ') === -1) ok = false;
        c.hidden = !ok;
        if (ok) total++;
      });

      contagem.textContent = total + (total === 1 ? ' receita encontrada' : ' receitas encontradas');
      vazio.hidden = total > 0;
      grade.hidden = total === 0;
      marcarChips();
      if (chipFav) chipFav.setAttribute('aria-pressed', estado.favs ? 'true' : 'false');
      if (vazioTxt) {
        vazioTxt.textContent = (estado.favs && !lista(K_FAV).length)
          ? 'Você ainda não salvou nenhuma receita. Toque no coração de uma receita para guardá-la aqui.'
          : textoVazioPadrao;
      }

      if (usaUrl && window.history && history.replaceState) {
        try {
          var u = new URLSearchParams();
          if (campo.value.trim()) u.set('q', campo.value.trim());
          if (estado.cat) u.set('cat', estado.cat);
          var s = u.toString();
          history.replaceState(null, '', location.pathname + (s ? '?' + s : '') + location.hash);
        } catch (e) { /* ignora */ }
      }
    }

    function limpar() {
      campo.value = '';
      selDif.value = selTempo.value = selRef.value = '';
      estado.cat = '';
      estado.favs = false;
      aplicar();
      campo.focus();
    }

    campo.addEventListener('input', aplicar);
    [selDif, selTempo, selRef].forEach(function (s) { s.addEventListener('change', aplicar); });
    chips.forEach(function (c) {
      c.addEventListener('click', function () { estado.cat = c.getAttribute('data-cat'); aplicar(); });
    });
    if (chipFav) chipFav.addEventListener('click', function () { estado.favs = !estado.favs; aplicar(); });
    reaplicarCatalogo = function () { if (estado.favs) aplicar(); };
    raiz.querySelector('#limpar').addEventListener('click', limpar);
    raiz.querySelector('#limpar2').addEventListener('click', limpar);
    if (form) form.addEventListener('submit', function (e) { e.preventDefault(); campo.blur(); });

    aplicar();
    if (location.hash === '#busca' && usaUrl) campo.focus();
  }

  /* ------------------------------------------------------------------
     Compartilhar
     ------------------------------------------------------------------ */
  function urlDaPagina() {
    var l = document.querySelector('link[rel="canonical"]');
    return l ? l.href : location.href.split('#')[0];
  }

  function iniciarCompartilhar(raiz) {
    [].forEach.call(raiz.querySelectorAll('[data-compartilhar]'), function (bloco) {
      var titulo = bloco.getAttribute('data-titulo');
      var url = urlDaPagina();
      var texto = titulo + ' – Chefio Receitas';
      var mapa = {
        whatsapp: 'https://wa.me/?text=' + enc(texto + ' ' + url),
        facebook: 'https://www.facebook.com/sharer/sharer.php?u=' + enc(url),
        x: 'https://twitter.com/intent/tweet?text=' + enc(texto) + '&url=' + enc(url),
        telegram: 'https://t.me/share/url?url=' + enc(url) + '&text=' + enc(texto),
        email: 'mailto:?subject=' + enc(texto) + '&body=' + enc('Olha esta receita: ' + titulo + '\n' + url)
      };
      [].forEach.call(bloco.querySelectorAll('[data-rede]'), function (a) {
        a.setAttribute('href', mapa[a.getAttribute('data-rede')]);
      });
      var nativo = bloco.querySelector('[data-acao="nativo"]');
      if (nativo && navigator.share) nativo.hidden = false;
    });
  }

  function copiar(texto, bloco, msgOk) {
    var ok1 = msgOk || 'Link copiado!';
    function plano() {
      var ta = document.createElement('textarea');
      ta.value = texto; ta.setAttribute('readonly', '');
      ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      ta.remove();
      aviso(bloco, ok ? ok1 : 'Não foi possível copiar. Selecione o texto e copie manualmente.');
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(texto).then(function () { aviso(bloco, ok1); }, plano);
    } else {
      plano();
    }
  }

  /* ------------------------------------------------------------------
     Eventos gerais (ficam ativos o tempo todo, valem para qualquer página)
     ------------------------------------------------------------------ */
  document.addEventListener('click', function (e) {
    var alvo = e.target;
    if (!alvo.closest) return;

    /* menu no celular */
    var btn = alvo.closest('.menu-btn');
    if (btn) {
      var menu = document.getElementById('menu');
      var aberto = menu.classList.toggle('aberto');
      btn.setAttribute('aria-expanded', aberto ? 'true' : 'false');
      btn.setAttribute('aria-label', aberto ? 'Fechar menu' : 'Abrir menu');
      return;
    }

    /* fecha o menu "Categorias" ao clicar fora dele */
    [].forEach.call(document.querySelectorAll('details.menu-cats[open]'), function (d) {
      if (!d.contains(alvo)) d.open = false;
    });

    /* tema claro/escuro */
    if (alvo.closest('[data-tema]')) {
      var novo = temaAtual() === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', novo);
      gravar(K_TEMA, novo);
      return;
    }

    /* favoritos */
    var fav = alvo.closest('[data-fav]');
    if (fav) {
      var ligou = alternarFav(fav.getAttribute('data-fav'));
      atualizarFavs();
      if (reaplicarCatalogo) reaplicarCatalogo();
      var artFav = fav.closest('.receita');
      if (artFav) aviso(artFav.querySelector('.acoes'), ligou ? 'Receita salva nos favoritos.' : 'Receita removida dos favoritos.');
      return;
    }

    /* adicionar ingredientes à lista de compras */
    var addC = alvo.closest('[data-compras-add]');
    if (addC) {
      var artC = addC.closest('.receita');
      var n = adicionarReceitaALista(artC);
      aviso(artC.querySelector('.acoes'), n ? 'Ingredientes adicionados à lista.' : 'Esses ingredientes já estão na lista.');
      return;
    }

    /* modo cozinha */
    var coz = alvo.closest('[data-cozinha]');
    if (coz) { abrirCozinha(coz.closest('.receita'), coz); return; }

    /* botão "Surpreenda-me" */
    var sorteio = alvo.closest('[data-aleatorio]');
    if (sorteio) {
      var lista = sorteio.getAttribute('data-lista').split(',');
      var outras = lista.filter(function (h) {
        var arq = h.split('/').pop();
        return location.pathname.indexOf(arq) === -1;
      });
      if (outras.length) lista = outras;
      var escolha = lista[Math.floor(Math.random() * lista.length)];
      var a = document.createElement('a');
      a.setAttribute('href', escolha);
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      a.remove();
      return;
    }

    /* botões de compartilhar */
    var acao = alvo.closest('[data-acao]');
    if (acao) {
      var bloco = acao.closest('[data-compartilhar]');
      var tipo = acao.getAttribute('data-acao');
      if (tipo === 'copiar' && bloco) copiar(urlDaPagina(), bloco);
      if (tipo === 'imprimir') window.print();
      if (tipo === 'nativo' && bloco && navigator.share) {
        navigator.share({ title: bloco.getAttribute('data-titulo'), url: urlDaPagina() }).catch(function () {});
      }
      return;
    }

    /* clicar num link do menu fecha o menu no celular */
    if (alvo.closest('.menu a')) {
      var m = document.getElementById('menu');
      if (m) m.classList.remove('aberto');
      var b = document.querySelector('.menu-btn');
      if (b) b.setAttribute('aria-expanded', 'false');
    }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    [].forEach.call(document.querySelectorAll('details.menu-cats[open]'), function (d) { d.open = false; });
    var m = document.getElementById('menu');
    if (m && m.classList.contains('aberto')) {
      m.classList.remove('aberto');
      var b = document.querySelector('.menu-btn');
      if (b) { b.setAttribute('aria-expanded', 'false'); b.focus(); }
    }
  });

  /* ------------------------------------------------------------------
     Início de cada página
     ------------------------------------------------------------------ */
  function iniciarPagina() {
    var raiz = document.getElementById('conteudo') || document.querySelector('main');
    if (!raiz || raiz.getAttribute('data-ok')) return;
    raiz.setAttribute('data-ok', '1');
    iniciarCatalogo(raiz);
    iniciarCompartilhar(raiz);
    iniciarCompras(raiz);
    atualizarFavs(raiz);
    contarCompras();
  }

  window.Chefio = { iniciarPagina: iniciarPagina };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciarPagina);
  } else {
    iniciarPagina();
  }
})();
