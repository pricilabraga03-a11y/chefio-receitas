/* Aplica o tema escolhido antes de a página aparecer (evita "piscar"). Só usa o que a pessoa escolheu no botão de tema. */
(function () {
  try {
    var t = JSON.parse(window.localStorage.getItem('chefio:tema'));
    if (t === 'dark' || t === 'light') document.documentElement.setAttribute('data-theme', t);
  } catch (e) { /* sem armazenamento: segue o tema do sistema */ }
})();
